/**
 * ATLAS API client — drop into the React frontend (e.g. src/api.js) to replace
 * the in-browser RAW computation with live backend calls.
 *
 * Usage:
 *   import { api } from "./api";
 *   const overview = await api.overview();
 *   const reply    = await api.chat("What's the blast radius of C2?");
 *
 * Set VITE_ATLAS_API in your .env (defaults to http://localhost:8000).
 */
const BASE = import.meta?.env?.VITE_ATLAS_API || "http://localhost:8000";

async function get(path) {
  const r = await fetch(`${BASE}${path}`);
  if (!r.ok) throw new Error(`${path} -> ${r.status}`);
  return r.json();
}
async function post(path, body) {
  const r = await fetch(`${BASE}${path}`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(body),
  });
  if (!r.ok) throw new Error(`${path} -> ${r.status}`);
  return r.json();
}

export const api = {
  // dashboard / logs / spikes
  overview: () => get("/api/overview"),
  logs: ({ level, source, limit = 200, offset = 0 } = {}) =>
    get(`/api/logs?limit=${limit}&offset=${offset}` +
        (level ? `&level=${level}` : "") + (source ? `&source=${encodeURIComponent(source)}` : "")),
  volume: () => get("/api/logs/volume"),
  spikes: (z = 2.4) => get(`/api/spikes?z=${z}`),
  noisy: (top = 8) => get(`/api/noisy?top=${top}`),
  metrics: (computeId) => get(`/api/metrics/${computeId}`),

  // predict
  forecast: (horizon = 12) => get(`/api/predict/forecast?horizon=${horizon}`),
  risk: (top) => get(`/api/risk${top ? `?top=${top}` : ""}`),

  // graph
  topology: () => get("/api/graph/topology"),
  node: (id) => get(`/api/graph/node/${id}`),
  search: (q) => get(`/api/graph/search?q=${encodeURIComponent(q)}`),
  blast: (computeId) => get(`/api/graph/blast/${computeId}`),

  // incidents / RCA / remediation / alerting
  incidents: () => get("/api/incidents"),
  incident: (id) => get(`/api/incidents/${id}`),
  rca: (question) => post("/api/incidents/rca", { question }),
  remediate: (incidentId) => post("/api/incidents/remediate", { incident_id: incidentId }),
  alert: (incidentId) => post("/api/incidents/alert", { incident_id: incidentId }),
  alertPreview: (id) => get(`/api/incidents/${id}/alert-preview`),

  // assistant (RAG over Ollama + FAISS)
  chat: (question, k = 6) => post("/api/assistant/chat", { question, k }),
  reindex: () => post("/api/assistant/reindex", {}),

  // meta
  health: () => get("/health"),
};
