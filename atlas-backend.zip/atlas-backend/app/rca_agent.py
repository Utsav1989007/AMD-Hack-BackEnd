"""Agentic RCA + remediation using a LangChain 1.x agent over Ollama.

`create_agent` builds a tool-calling agent (langgraph runtime). The agent is
given grounded tools — blast radius, node lookup, incident facts, service risk,
and a remediation executor — so it reasons over real graph facts rather than
its imagination. Use a tool-capable Ollama model (e.g. llama3.1).
"""
from __future__ import annotations

import json
from functools import lru_cache

from langchain.agents import create_agent
from langchain_core.tools import tool

from .analytics import service_risk
from .graph_service import find_node, label_blast, neighbors
from .incidents import build_incidents, get_incident
from .llm import get_llm
from .remediation import remediate_incident


@tool
def get_blast_radius(compute_id: str) -> str:
    """Return the upstream impact (apps, services, domains, DBs) of a compute node id like 'C13'."""
    bl = label_blast(compute_id.strip().upper())
    return json.dumps(bl["counts"]) + " | services: " + ", ".join(bl["services"][:8])


@tool
def lookup_node(query: str) -> str:
    """Look up a node by id or name and return its type and direct neighbours."""
    n = find_node(query)
    if not n:
        return f"no node matching '{query}'"
    info = neighbors(n.id)
    nbrs = ", ".join(f"{x['label']}({x['id']})" for x in info["neighbors"][:10])
    return f"{n.label} [{n.id}] type={n.type}. Neighbours: {nbrs}"


@tool
def incident_facts(incident_id: str) -> str:
    """Get recorded facts for an incident id like 'INC-1042': epicenter, signal, metrics, root causes."""
    inc = get_incident(incident_id.strip())
    if not inc:
        return "unknown incident. Known: " + ", ".join(i.id for i in build_incidents())
    rc = "; ".join(f"{c['hypothesis']} ({int(c['confidence']*100)}%)" for c in inc.root_causes)
    return (f"{inc.id} on {inc.epicenter_label}[{inc.epicenter}] kind={inc.kind} "
            f"sev={inc.severity} error@peak={inc.error_at_peak} cpu={inc.cpu_at_peak} "
            f"p99={inc.latency_at_peak}ms. Candidate root causes: {rc}. "
            f"Recommended fix: {inc.recommended_fix['title']}.")


@tool
def top_service_risk(query: str = "") -> str:
    """List the business services with the highest predicted failure risk."""
    return "; ".join(f"{r['name']}({r['id']}) {r['risk']}%" for r in service_risk(top=6))


@tool
def run_remediation(incident_id: str) -> str:
    """Execute the recommended remediation for an incident id (simulated unless wired to infra)."""
    return json.dumps(remediate_incident(incident_id.strip()))[:500]


TOOLS = [get_blast_radius, lookup_node, incident_facts, top_service_risk, run_remediation]

SYSTEM = (
    "You are ATLAS, an autonomous SRE agent for a retail enterprise. "
    "Perform root-cause analysis and, when asked, remediation. "
    "Always ground your reasoning in tool results — never invent metrics, ids or hostnames. "
    "Finish with: the single most likely root cause, the evidence (blast radius / metrics), "
    "and a concrete recommended remediation. Cite node and incident ids. Be concise."
)


@lru_cache
def get_agent():
    return create_agent(get_llm(), TOOLS, system_prompt=SYSTEM)


def run_rca(question: str) -> dict:
    try:
        result = get_agent().invoke({"messages": [{"role": "user", "content": question}]})
        msgs = result.get("messages", [])
        answer = msgs[-1].content if msgs else ""
        tool_calls = [m.name for m in msgs if getattr(m, "type", "") == "tool"]
        return {"answer": (answer or "").strip(), "tools_used": tool_calls}
    except Exception as e:  # noqa: BLE001
        return {"answer": "", "error": str(e)}
