"""FAISS vector store for retrieval-augmented infra Q&A.

Documents are assembled from three grounded sources:
  1. every graph node, described in natural language with its lineage
  2. recent ERROR/WARN log lines
  3. open incidents with their RCA + blast radius

Embeddings come from Ollama (`nomic-embed-text` by default). The index is
persisted to disk and reloaded on startup.
"""
from __future__ import annotations

import threading

from langchain_community.vectorstores import FAISS
from langchain_core.documents import Document

from .config import get_settings
from .data_loader import LAYER, get_graph
from .graph_service import label_blast
from .incidents import build_incidents
from .llm import get_embeddings
from .telemetry import get_telemetry

_store: FAISS | None = None
_lock = threading.Lock()


def _node_documents() -> list[Document]:
    g = get_graph()
    docs = []
    for n in g.nodes:
        kind = LAYER.get(n.type, {}).get("label", n.type)
        nbrs = [g.by_id[i].label for i in g.neighbors(n.id)][:12]
        meta_bits = ", ".join(f"{k}={v}" for k, v in n.meta.items() if v)
        text = (
            f"{kind} '{n.label}' (id {n.id}). "
            + (f"Attributes: {meta_bits}. " if meta_bits else "")
            + (f"Directly connected to: {', '.join(nbrs)}." if nbrs else "No direct connections.")
        )
        docs.append(Document(page_content=text,
                             metadata={"kind": "node", "id": n.id, "type": n.type, "label": n.label}))
    return docs


def _log_documents(limit: int = 400) -> list[Document]:
    tel = get_telemetry()
    notable = [l for l in tel.logs if l.level in ("ERROR", "WARN")][-limit:]
    docs = []
    for l in notable:
        text = f"[{l.level}] {l.ts} source {l.source}: {l.message}"
        docs.append(Document(page_content=text,
                             metadata={"kind": "log", "level": l.level,
                                       "compute": l.compute_id, "app": l.app_id or ""}))
    return docs


def _incident_documents() -> list[Document]:
    docs = []
    for inc in build_incidents():
        bl = inc.blast_labels
        top = inc.root_causes[0]
        text = (
            f"Incident {inc.id} (severity {inc.severity}) on compute "
            f"{inc.epicenter_label} [{inc.epicenter}], type {inc.kind}. "
            f"Most likely root cause: {top['hypothesis']} "
            f"(confidence {int(top['confidence']*100)}%). "
            f"Recommended remediation: {inc.recommended_fix['title']}. "
            f"Blast radius: {bl['counts']['apps']} applications, "
            f"{bl['counts']['services']} business services, "
            f"{bl['counts']['domains']} domains affected. "
            f"Impacted services include: {', '.join(bl['services'][:8])}."
        )
        docs.append(Document(page_content=text,
                             metadata={"kind": "incident", "id": inc.id,
                                       "epicenter": inc.epicenter, "severity": inc.severity}))
    return docs


def build_documents() -> list[Document]:
    return _node_documents() + _log_documents() + _incident_documents()


def build_store(force: bool = False) -> FAISS:
    global _store
    with _lock:
        s = get_settings()
        path = s.faiss_path
        emb = get_embeddings()
        if not force and not s.faiss_force_rebuild and (path / "index.faiss").exists():
            _store = FAISS.load_local(str(path), emb, allow_dangerous_deserialization=True)
            return _store
        docs = build_documents()
        _store = FAISS.from_documents(docs, emb)
        path.mkdir(parents=True, exist_ok=True)
        _store.save_local(str(path))
        return _store


def get_store() -> FAISS:
    global _store
    if _store is None:
        return build_store()
    return _store


def retrieve(query: str, k: int = 6) -> list[Document]:
    return get_store().similarity_search(query, k=k)
