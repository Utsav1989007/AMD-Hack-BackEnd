"""Grounded infrastructure chat.

Hybrid retrieval strategy:
  • deterministic structured facts for precise questions (counts, blast radius,
    risk, dependencies) — computed from the graph, never hallucinated;
  • FAISS semantic retrieval for everything else (logs, incidents, free-form);
  • Ollama LLM composes the final answer, constrained to the supplied context.
"""
from __future__ import annotations

import re

from langchain_core.output_parsers import StrOutputParser
from langchain_core.prompts import ChatPromptTemplate

from .analytics import noisy_sources, service_risk
from .data_loader import get_graph
from .graph_service import blast_radius, find_node, label_blast
from .llm import get_llm
from .vectorstore import retrieve

SYSTEM = (
    "You are ATLAS, an AIOps assistant for a retail enterprise's infrastructure. "
    "Answer ONLY from the CONTEXT and STRUCTURED FACTS provided. "
    "If the answer is not in the context, say you don't have that signal. "
    "Be concise and concrete; cite node ids and incident ids where relevant. "
    "Never invent metrics, hostnames, or numbers."
)

PROMPT = ChatPromptTemplate.from_messages([
    ("system", SYSTEM),
    ("human",
     "STRUCTURED FACTS:\n{facts}\n\n"
     "RETRIEVED CONTEXT:\n{context}\n\n"
     "QUESTION: {question}\n\nAnswer:"),
])


def _structured_facts(q: str) -> str:
    """Compute exact facts for common intents; returns '' if none apply."""
    g = get_graph()
    ql = q.lower()
    bits: list[str] = []

    # node-count questions
    if "how many" in ql or "count" in ql:
        types = {"domain": "domains", "capabilit": "capabilities", "service": "services",
                 "application": "applications", "app": "applications",
                 "compute": "compute nodes", "database": "databases", "network": "networks"}
        for key, label in types.items():
            if key in ql:
                n = len([x for x in g.nodes if x.type.startswith(key[:4]) or label.startswith(x.type)])
                # robust count by type
                tmap = {"domains": "domain", "capabilities": "capability", "services": "service",
                        "applications": "app", "compute nodes": "compute",
                        "databases": "database", "networks": "network"}
                n = len([x for x in g.nodes if x.type == tmap[label]])
                bits.append(f"There are {n} {label}.")
                break

    # blast radius
    m = re.search(r"\b(C\d+)\b", q, re.I)
    if m and ("blast" in ql or "impact" in ql or "affect" in ql or "radius" in ql):
        cid = m.group(1).upper()
        if cid in g.by_id:
            bl = label_blast(cid)
            c = bl["counts"]
            bits.append(
                f"Blast radius of {cid} ({g.by_id[cid].label}): {c['apps']} apps, "
                f"{c['services']} services, {c['domains']} domains, {c['databases']} DBs. "
                f"Impacted services: {', '.join(bl['services'][:8])}."
            )

    # risk
    if "risk" in ql or "fail" in ql or "predict" in ql:
        top = service_risk(top=5)
        bits.append("Top predicted-risk services: " +
                    "; ".join(f"{r['name']} ({r['id']}) {r['risk']}%" for r in top) + ".")

    # noisy
    if "nois" in ql or "loud" in ql or "most logs" in ql:
        ns = noisy_sources(top=5)
        bits.append("Noisiest sources: " +
                    "; ".join(f"{n['source']} ({n['errors']} errors/{n['total']} logs)" for n in ns) + ".")

    # direct dependency lookup
    node = None
    m2 = re.search(r"\b((BD|BC|BS|AS|APP|C|DB|N)\d+)\b", q, re.I)
    if m2:
        node = g.by_id.get(m2.group(1).upper())
    if node and ("depend" in ql or "connect" in ql or "relate" in ql or "linked" in ql):
        nbrs = [g.by_id[i].label for i in g.neighbors(node.id)][:10]
        bits.append(f"{node.label} ({node.id}) connects to: {', '.join(nbrs)}.")

    return "\n".join(bits)


def chat(question: str, k: int = 6) -> dict:
    facts = _structured_facts(question)
    docs = retrieve(question, k=k)
    context = "\n".join(f"- {d.page_content}" for d in docs) or "(no documents retrieved)"

    chain = PROMPT | get_llm() | StrOutputParser()
    answer = chain.invoke({
        "facts": facts or "(none)",
        "context": context,
        "question": question,
    })

    sources = [{"kind": d.metadata.get("kind"), "ref": d.metadata.get("id")
                or d.metadata.get("source") or d.metadata.get("compute"),
                "snippet": d.page_content[:160]} for d in docs]
    return {"answer": answer.strip(), "facts_used": facts, "sources": sources}
