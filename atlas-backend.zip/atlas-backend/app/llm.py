"""Factories for the Ollama chat model and embedding model (via langchain-ollama).
Cached so a single client is reused across requests."""
from __future__ import annotations

from functools import lru_cache

import httpx

from .config import get_settings


@lru_cache
def get_llm():
    from langchain_ollama import ChatOllama

    s = get_settings()
    return ChatOllama(
        base_url=s.ollama_base_url,
        model=s.ollama_llm_model,
        temperature=s.llm_temperature,
        timeout=s.ollama_timeout,
    )


@lru_cache
def get_embeddings():
    from langchain_ollama import OllamaEmbeddings

    s = get_settings()
    return OllamaEmbeddings(
        base_url=s.ollama_base_url,
        model=s.ollama_embed_model,
    )


def ollama_health() -> dict:
    """Check Ollama is reachable and report which required models are present."""
    s = get_settings()
    info = {"reachable": False, "models": [], "llm_ready": False, "embed_ready": False}
    try:
        r = httpx.get(f"{s.ollama_base_url}/api/tags", timeout=5)
        r.raise_for_status()
        tags = [m["name"] for m in r.json().get("models", [])]
        info["reachable"] = True
        info["models"] = tags
        info["llm_ready"] = any(t.split(":")[0] == s.ollama_llm_model.split(":")[0] for t in tags)
        info["embed_ready"] = any(t.split(":")[0] == s.ollama_embed_model.split(":")[0] for t in tags)
    except Exception as e:  # noqa: BLE001
        info["error"] = str(e)
    return info
