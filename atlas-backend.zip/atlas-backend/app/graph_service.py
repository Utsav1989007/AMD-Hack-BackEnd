"""Graph queries: blast-radius (impact propagation), lineage, neighbour lookup,
and a serialisable subgraph for the frontend topology view."""
from __future__ import annotations

from .data_loader import LAYER, Graph, get_graph


def find_node(query: str):
    """Resolve a node by exact id (case-insensitive) or fuzzy label match."""
    g = get_graph()
    q = query.strip()
    if q.upper() in g.by_id:
        return g.by_id[q.upper()]
    if q in g.by_id:
        return g.by_id[q]
    ql = q.lower()
    # exact label, then contains
    for n in g.nodes:
        if n.label.lower() == ql:
            return n
    for n in g.nodes:
        if ql in n.label.lower():
            return n
    return None


def blast_radius(compute_id: str) -> dict:
    """Given a compute node, walk upstream to every impacted entity."""
    g: Graph = get_graph()
    apps = set(g.apps_on_compute.get(compute_id, []))
    appsvcs, svcs, caps, doms, dbs = set(), set(), set(), set(), set()

    for app in apps:
        dbs |= set(g.db_of_app.get(app, []))
        for e in g.out.get(app, []):
            if e.rel == "EXPOSES":
                appsvcs.add(e.target)

    for asv in appsvcs:
        svcs |= set(g.svc_of_appservice.get(asv, []))

    for sv in svcs:
        node = g.by_id.get(sv)
        if node and node.meta.get("capability_id"):
            caps.add(node.meta["capability_id"])

    for cap in caps:
        node = g.by_id.get(cap)
        if node and node.meta.get("domain_id"):
            doms.add(node.meta["domain_id"])

    return {
        "epicenter": compute_id,
        "apps": sorted(apps),
        "app_services": sorted(appsvcs),
        "services": sorted(svcs),
        "capabilities": sorted(caps),
        "domains": sorted(doms),
        "databases": sorted(dbs),
        "counts": {
            "apps": len(apps), "services": len(svcs),
            "capabilities": len(caps), "domains": len(doms), "databases": len(dbs),
        },
    }


def label_blast(compute_id: str) -> dict:
    """Blast radius with human labels (for narration / email)."""
    g = get_graph()
    b = blast_radius(compute_id)
    lab = lambda ids: [g.by_id[i].label for i in ids if i in g.by_id]
    return {
        "epicenter": g.by_id[compute_id].label if compute_id in g.by_id else compute_id,
        "apps": lab(b["apps"]),
        "services": lab(b["services"]),
        "capabilities": lab(b["capabilities"]),
        "domains": lab(b["domains"]),
        "databases": lab(b["databases"]),
        "counts": b["counts"],
    }


def neighbors(node_id: str) -> dict:
    g = get_graph()
    node = g.by_id.get(node_id)
    if not node:
        return {}
    nbrs = []
    for nid in g.neighbors(node_id):
        n = g.by_id[nid]
        nbrs.append({"id": n.id, "label": n.label, "type": n.type})
    return {"id": node.id, "label": node.label, "type": node.type, "meta": node.meta, "neighbors": nbrs}


def export_subgraph() -> dict:
    """Full topology serialised for the frontend force-graph."""
    g = get_graph()
    nodes = [{
        "id": n.id, "label": n.label, "type": n.type,
        "layer": LAYER.get(n.type, {}).get("idx", 5),
        "meta": n.meta,
    } for n in g.nodes]
    edges = [{
        "source": e.source, "target": e.target, "rel": e.rel,
        "criticality": e.criticality,
    } for e in g.edges]
    return {"nodes": nodes, "edges": edges,
            "stats": {"nodes": len(nodes), "edges": len(edges)}}
