"""ATLAS backend — FastAPI app wiring telemetry, graph analytics, RAG chat
(Ollama + FAISS) and the RCA/remediation agent into one API for the frontend."""
from __future__ import annotations

import logging
from contextlib import asynccontextmanager

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from .config import get_settings
from .data_loader import get_graph
from .llm import ollama_health
from .routers import assistant, graph, incidents, predict, telemetry
from .telemetry import get_telemetry

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(name)s: %(message)s")
log = logging.getLogger("atlas")


@asynccontextmanager
async def lifespan(app: FastAPI):
    s = get_settings()
    log.info("Loading topology graph from %s ...", s.data_path)
    g = get_graph()
    log.info("Graph: %d nodes, %d edges", len(g.nodes), len(g.edges))
    get_telemetry()
    log.info("Telemetry generated (seed=%s)", s.telemetry_seed)

    health = ollama_health()
    if not health["reachable"]:
        log.warning("Ollama not reachable at %s — LLM endpoints will error until it's up.",
                    s.ollama_base_url)
    else:
        log.info("Ollama OK. LLM '%s' ready=%s, embed '%s' ready=%s",
                 s.ollama_llm_model, health["llm_ready"],
                 s.ollama_embed_model, health["embed_ready"])
        # Build the vector store eagerly only if embeddings are available.
        if health["embed_ready"]:
            try:
                from .vectorstore import build_store
                store = build_store()
                log.info("FAISS index ready: %d vectors", store.index.ntotal)
            except Exception as e:  # noqa: BLE001
                log.warning("FAISS index build deferred: %s", e)
        else:
            log.warning("Embedding model '%s' not pulled — run: ollama pull %s",
                        s.ollama_embed_model, s.ollama_embed_model)
    yield
    log.info("ATLAS backend shutting down.")


app = FastAPI(
    title="ATLAS API",
    description="Autonomous Telemetry, Lineage & Anomaly Supervisor — AIOps backend "
                "(FastAPI · LangChain · Ollama · FAISS).",
    version="1.0.0",
    lifespan=lifespan,
)

settings = get_settings()
app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.cors_list,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

for r in (telemetry.router, graph.router, predict.router, incidents.router, assistant.router):
    app.include_router(r)


@app.get("/", tags=["meta"])
def root():
    g = get_graph()
    return {
        "service": "ATLAS API", "version": "1.0.0",
        "graph": {"nodes": len(g.nodes), "edges": len(g.edges)},
        "docs": "/docs",
    }


@app.get("/health", tags=["meta"])
def health():
    return {"status": "ok", "ollama": ollama_health()}
