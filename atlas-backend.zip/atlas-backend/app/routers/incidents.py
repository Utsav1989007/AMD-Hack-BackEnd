"""Incidents, RCA (LLM agent), remediation and email alerting."""
from __future__ import annotations

from dataclasses import asdict

from fastapi import APIRouter, HTTPException

from ..email_alert import compose_alert, send_alert
from ..incidents import build_incidents, get_incident
from ..rca_agent import run_rca
from ..remediation import execute, remediate_incident
from ..schemas import AlertRequest, RCARequest, RemediationRequest

router = APIRouter(prefix="/api/incidents", tags=["incidents"])


@router.get("")
def list_incidents():
    return {"incidents": [asdict(i) for i in build_incidents()]}


@router.get("/{inc_id}")
def incident(inc_id: str):
    inc = get_incident(inc_id)
    if not inc:
        raise HTTPException(404, f"incident {inc_id} not found")
    return asdict(inc)


@router.post("/rca")
def rca(req: RCARequest):
    """Run the LangChain RCA agent (uses Ollama + grounded tools)."""
    return run_rca(req.question)


@router.post("/remediate")
def remediate(req: RemediationRequest):
    if req.incident_id:
        return remediate_incident(req.incident_id)
    if req.action and req.target:
        return execute(req.action, req.target.upper(), req.params)
    raise HTTPException(400, "provide either incident_id or (action + target)")


@router.post("/alert")
def alert(req: AlertRequest):
    """Flag an incident to on-call via email (SMTP, or dry-run if unconfigured)."""
    return send_alert(req.incident_id)


@router.get("/{inc_id}/alert-preview")
def alert_preview(inc_id: str):
    inc = get_incident(inc_id)
    if not inc:
        raise HTTPException(404, f"incident {inc_id} not found")
    return compose_alert(inc)
