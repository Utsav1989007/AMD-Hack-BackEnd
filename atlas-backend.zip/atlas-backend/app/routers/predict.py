"""Forecasting endpoints — power the Predict view."""
from __future__ import annotations

from fastapi import APIRouter

from ..analytics import forecast, service_risk

router = APIRouter(prefix="/api/predict", tags=["predict"])


@router.get("/forecast")
def error_forecast(horizon: int = 12):
    return forecast(horizon=horizon)


@router.get("/risk")
def predicted_risk(top: int = 10):
    return {"services": service_risk(top=top)}
