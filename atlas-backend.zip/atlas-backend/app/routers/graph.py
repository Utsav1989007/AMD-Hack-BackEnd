"""Graph / topology endpoints — power the frontend force-graph and inspector."""
from __future__ import annotations

from fastapi import APIRouter, HTTPException

from ..graph_service import blast_radius, export_subgraph, find_node, label_blast, neighbors

router = APIRouter(prefix="/api/graph", tags=["graph"])


@router.get("/topology")
def topology():
    """Full node + edge list for the topology visualisation."""
    return export_subgraph()


@router.get("/node/{node_id}")
def node(node_id: str):
    info = neighbors(node_id.upper())
    if not info:
        raise HTTPException(404, f"node {node_id} not found")
    return info


@router.get("/search")
def search(q: str):
    n = find_node(q)
    if not n:
        raise HTTPException(404, f"no node matching '{q}'")
    return {"id": n.id, "label": n.label, "type": n.type, "meta": n.meta}


@router.get("/blast/{compute_id}")
def blast(compute_id: str):
    cid = compute_id.upper()
    return {"ids": blast_radius(cid), "labels": label_blast(cid)}
