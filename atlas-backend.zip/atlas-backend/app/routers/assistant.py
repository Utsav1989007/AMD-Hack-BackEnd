"""Conversational assistant — grounded RAG over the infra (Ollama + FAISS)."""
from __future__ import annotations

from fastapi import APIRouter

from ..rag_chat import chat
from ..schemas import ChatRequest
from ..vectorstore import build_store

router = APIRouter(prefix="/api/assistant", tags=["assistant"])


@router.post("/chat")
def assistant_chat(req: ChatRequest):
    return chat(req.question, k=req.k)


@router.post("/reindex")
def reindex():
    """Rebuild the FAISS index from current topology, logs and incidents."""
    store = build_store(force=True)
    return {"ok": True, "vectors": store.index.ntotal}
