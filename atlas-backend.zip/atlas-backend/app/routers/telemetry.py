"""Logs, metrics, spikes and overview KPIs — power the dashboard views."""
from __future__ import annotations

from dataclasses import asdict

from fastapi import APIRouter, Query

from ..analytics import (detect_spikes, domain_health, kpis, noisy_sources,
                         service_risk)
from ..telemetry import get_telemetry

router = APIRouter(prefix="/api", tags=["telemetry"])


@router.get("/overview")
def overview():
    tel = get_telemetry()
    return {
        "kpis": kpis(),
        "volume": tel.volume,
        "domain_health": domain_health(),
        "spikes": [asdict(s) for s in detect_spikes()],
    }


@router.get("/logs")
def logs(
    level: str | None = Query(None, pattern="^(INFO|WARN|ERROR)$"),
    source: str | None = None,
    limit: int = 200,
    offset: int = 0,
):
    tel = get_telemetry()
    rows = tel.logs
    if level:
        rows = [l for l in rows if l.level == level]
    if source:
        s = source.lower()
        rows = [l for l in rows if s in l.source.lower() or s in l.message.lower()]
    rows = list(reversed(rows))  # newest first
    total = len(rows)
    page = rows[offset:offset + limit]
    return {
        "total": total, "offset": offset, "limit": limit,
        "logs": [asdict(l) for l in page],
    }


@router.get("/logs/volume")
def volume():
    return {"volume": get_telemetry().volume}


@router.get("/spikes")
def spikes(z: float = 2.4):
    return {"spikes": [asdict(s) for s in detect_spikes(z_thresh=z)]}


@router.get("/noisy")
def noisy(top: int = 8):
    return {"sources": noisy_sources(top=top)}


@router.get("/metrics/{compute_id}")
def compute_metrics(compute_id: str):
    tel = get_telemetry()
    cs = tel.series.get(compute_id.upper())
    if not cs:
        return {"error": f"no metrics for {compute_id}"}
    return {
        "compute_id": cs.compute_id, "times": tel.times,
        "cpu": cs.cpu, "latency": cs.latency, "error": cs.error, "throughput": cs.tput,
    }


@router.get("/risk")
def risk(top: int | None = None):
    return {"services": service_risk(top=top)}
