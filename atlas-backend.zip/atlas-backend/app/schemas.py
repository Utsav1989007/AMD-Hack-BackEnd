"""Request/response models for the API."""
from __future__ import annotations

from pydantic import BaseModel, Field


class ChatRequest(BaseModel):
    question: str = Field(..., min_length=1, examples=["What's the blast radius of C13?"])
    k: int = 6


class RCARequest(BaseModel):
    question: str = Field(..., examples=["Diagnose incident INC-1042 and recommend a fix"])


class RemediationRequest(BaseModel):
    incident_id: str | None = None
    action: str | None = Field(None, examples=["restart_service", "scale_resources"])
    target: str | None = Field(None, examples=["C13"])
    params: dict | None = None


class AlertRequest(BaseModel):
    incident_id: str = Field(..., examples=["INC-1042"])
