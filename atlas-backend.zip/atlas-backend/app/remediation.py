"""Remediation executors. In DRY_RUN (default) these simulate the action and
return a structured result. To go live, implement the bodies against your
orchestrator (kubectl / Kubernetes API, Ansible, cloud SDK) — the interface and
return shape stay identical so the agent and frontend need no changes."""
from __future__ import annotations

import time
import uuid
from datetime import datetime, timezone

from .config import get_settings
from .incidents import REMEDIATIONS, get_incident


def _now() -> str:
    return datetime.now(timezone.utc).isoformat()


def execute(action: str, target: str, params: dict | None = None) -> dict:
    """Run (or simulate) a remediation action against a target compute/app."""
    s = get_settings()
    params = params or {}
    plan = next((r for r in REMEDIATIONS.values() if r["action"] == action), None)
    if plan is None:
        return {"ok": False, "error": f"unknown action '{action}'"}

    run_id = f"rem-{uuid.uuid4().hex[:8]}"
    steps_log = []

    for step in plan["steps"]:
        # ---- real implementation goes here (per action) ----
        # e.g. if action == "restart_service":
        #          subprocess.run(["kubectl","rollout","restart",f"deploy/{target}"])
        #      elif action == "scale_resources":
        #          k8s.scale(target, replicas=params.get("replicas"))
        if not s.remediation_dry_run:
            # Intentionally not wired — refuse to claim a real action happened.
            return {"ok": False, "error": "live remediation not configured; "
                                          "implement executors in remediation.py"}
        time.sleep(0.0)  # placeholder for async op
        steps_log.append({"step": step, "status": "done", "at": _now()})

    return {
        "ok": True,
        "run_id": run_id,
        "action": action,
        "target": target,
        "title": plan["title"],
        "risk": plan["risk"],
        "dry_run": s.remediation_dry_run,
        "steps": steps_log,
        "note": "SIMULATED — no real infrastructure was modified."
                if s.remediation_dry_run else "executed",
        "finished_at": _now(),
    }


def remediate_incident(inc_id: str) -> dict:
    inc = get_incident(inc_id)
    if not inc:
        return {"ok": False, "error": f"incident {inc_id} not found"}
    fix = inc.recommended_fix
    return execute(fix["action"], inc.epicenter, {"incident": inc_id})
