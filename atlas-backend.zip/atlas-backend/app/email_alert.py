"""Email alerting. Composes a real on-call alert from an incident and sends it
via SMTP. If SMTP_HOST is unset it runs in dry-run mode and returns the composed
message without sending (so the dashboard's 'flag' button still works locally)."""
from __future__ import annotations

import smtplib
import ssl
from email.message import EmailMessage

from .config import get_settings
from .incidents import Incident, get_incident


def compose_alert(inc: Incident) -> dict:
    s = get_settings()
    top = inc.root_causes[0]
    bl = inc.blast_labels["counts"]
    subject = f"[{inc.severity.upper()}] {inc.id} — {inc.kind} on {inc.epicenter_label}"
    body = f"""ATLAS automated incident alert
==================================================
Incident : {inc.id}
Severity : {inc.severity.upper()}
Epicenter: {inc.epicenter_label} ({inc.epicenter})
Signal   : {inc.kind}  |  error@peak={inc.error_at_peak}  cpu={inc.cpu_at_peak}%  p99={inc.latency_at_peak}ms

PROBABLE ROOT CAUSE
  {top['hypothesis']}  (confidence {int(top['confidence']*100)}%)

RECOMMENDED REMEDIATION
  {inc.recommended_fix['title']}
  Steps: {' -> '.join(inc.recommended_fix['steps'])}

BLAST RADIUS
  {bl['apps']} applications · {bl['services']} business services · {bl['domains']} domains
  Key services: {', '.join(inc.blast_labels['services'][:6])}

-- ATLAS (Autonomous Telemetry, Lineage & Anomaly Supervisor)
"""
    return {"from": s.alert_from, "to": s.alert_to, "cc": s.alert_cc,
            "subject": subject, "body": body}


def send_alert(inc_id: str) -> dict:
    s = get_settings()
    inc = get_incident(inc_id)
    if not inc:
        return {"ok": False, "error": f"incident {inc_id} not found"}
    msg_fields = compose_alert(inc)

    if not s.smtp_host:
        return {"ok": True, "dispatched": False, "mode": "dry-run",
                "note": "SMTP_HOST not set — message composed but not sent.",
                "message": msg_fields}

    em = EmailMessage()
    em["From"] = msg_fields["from"]
    em["To"] = msg_fields["to"]
    if msg_fields["cc"]:
        em["Cc"] = msg_fields["cc"]
    em["Subject"] = msg_fields["subject"]
    em.set_content(msg_fields["body"])

    try:
        with smtplib.SMTP(s.smtp_host, s.smtp_port, timeout=20) as server:
            if s.smtp_use_tls:
                server.starttls(context=ssl.create_default_context())
            if s.smtp_user:
                server.login(s.smtp_user, s.smtp_password)
            server.send_message(em)
        return {"ok": True, "dispatched": True, "mode": "smtp",
                "to": msg_fields["to"], "subject": msg_fields["subject"]}
    except Exception as e:  # noqa: BLE001
        return {"ok": False, "dispatched": False, "error": str(e), "message": msg_fields}
