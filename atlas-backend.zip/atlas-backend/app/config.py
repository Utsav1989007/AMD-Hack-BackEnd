"""Central configuration, loaded from environment / .env."""
from __future__ import annotations

from functools import lru_cache
from pathlib import Path

from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file=".env", env_file_encoding="utf-8", extra="ignore")

    # Ollama
    ollama_base_url: str = "http://localhost:11434"
    ollama_llm_model: str = "llama3.1"
    ollama_embed_model: str = "nomic-embed-text"
    llm_temperature: float = 0.1
    ollama_timeout: int = 120

    # Vector store
    faiss_index_dir: str = "./faiss_index"
    faiss_force_rebuild: bool = False

    # Data
    data_dir: str = "./data"
    telemetry_seed: int = 20260614

    # CORS
    cors_origins: str = "http://localhost:5173,http://localhost:3000"

    # Email
    smtp_host: str = ""
    smtp_port: int = 587
    smtp_user: str = ""
    smtp_password: str = ""
    smtp_use_tls: bool = True
    alert_from: str = "atlas-bot@retailco.io"
    alert_to: str = "oncall-sre@retailco.io"
    alert_cc: str = "platform-eng@retailco.io"

    # Remediation
    remediation_dry_run: bool = True

    @property
    def cors_list(self) -> list[str]:
        return [o.strip() for o in self.cors_origins.split(",") if o.strip()]

    @property
    def data_path(self) -> Path:
        return Path(self.data_dir).resolve()

    @property
    def faiss_path(self) -> Path:
        return Path(self.faiss_index_dir).resolve()


@lru_cache
def get_settings() -> Settings:
    return Settings()
