"""Builds incidents from detected epicentres, ranks probable root causes, and
attaches a remediation plan. The deterministic facts here feed the LLM RCA
narration (see rca_agent.py) — the model explains, it does not invent."""
from __future__ import annotations

from dataclasses import asdict, dataclass, field
from functools import lru_cache

from .data_loader import get_graph
from .graph_service import blast_radius, label_blast
from .telemetry import BUCKETS, get_telemetry

SEV_BY_KIND = {"oom": "critical", "latency": "high", "errors": "high"}

CAUSE_LIBRARY = {
    "oom": [
        ("Memory leak / unbounded cache on the pod", 0.62, "restart"),
        ("Under-provisioned memory limit for current load", 0.24, "scale"),
        ("Traffic surge exceeding heap headroom", 0.14, "scale"),
    ],
    "latency": [
        ("Downstream dependency degradation (DB / API)", 0.48, "failover"),
        ("Connection-pool saturation", 0.31, "scale"),
        ("Slow query / missing index", 0.21, "rollback"),
    ],
    "errors": [
        ("Bad deploy / regression in recent release", 0.46, "rollback"),
        ("Upstream 5xx cascading through circuit breaker", 0.33, "failover"),
        ("Resource exhaustion causing request drops", 0.21, "scale"),
    ],
}

REMEDIATIONS = {
    "restart": {
        "action": "restart_service",
        "title": "Rolling restart of the affected workload",
        "steps": ["Cordon impacted pod", "Drain in-flight requests",
                  "Roll new replica", "Verify health probe", "Uncordon"],
        "risk": "low",
    },
    "scale": {
        "action": "scale_resources",
        "title": "Horizontal + vertical scale-out",
        "steps": ["Raise replica count +2", "Bump memory limit +50%",
                  "Wait for readiness", "Re-check saturation"],
        "risk": "low",
    },
    "failover": {
        "action": "failover",
        "title": "Fail over to healthy region / replica",
        "steps": ["Shift traffic to standby", "Verify replica lag",
                  "Promote standby", "Drain primary"],
        "risk": "medium",
    },
    "rollback": {
        "action": "rollback_deploy",
        "title": "Roll back to last-known-good revision",
        "steps": ["Identify previous revision", "Roll back deployment",
                  "Verify error rate recovery", "Open incident review"],
        "risk": "medium",
    },
}


@dataclass
class RootCause:
    hypothesis: str
    confidence: float
    fix: str


@dataclass
class Incident:
    id: str
    epicenter: str
    epicenter_label: str
    kind: str
    severity: str
    peak_bucket: int
    opened: str
    error_at_peak: float
    cpu_at_peak: float
    latency_at_peak: float
    root_causes: list[dict]
    recommended_fix: dict
    blast: dict
    blast_labels: dict = field(default_factory=dict)


@lru_cache
def build_incidents() -> list[Incident]:
    g = get_graph()
    tel = get_telemetry()
    incidents: list[Incident] = []
    for i, epi in enumerate(tel.epicentres):
        cs = tel.series[epi.compute_id]
        p = epi.peak_bucket
        causes = [RootCause(h, c, f) for (h, c, f) in CAUSE_LIBRARY[epi.kind]]
        top_fix = causes[0].fix
        incidents.append(Incident(
            id=f"INC-{1042 + i}",
            epicenter=epi.compute_id,
            epicenter_label=g.by_id[epi.compute_id].label,
            kind=epi.kind,
            severity=SEV_BY_KIND[epi.kind],
            peak_bucket=p,
            opened=tel.times[max(0, p - 3)],
            error_at_peak=cs.error[p],
            cpu_at_peak=cs.cpu[p],
            latency_at_peak=cs.latency[p],
            root_causes=[asdict(c) for c in causes],
            recommended_fix=REMEDIATIONS[top_fix],
            blast=blast_radius(epi.compute_id),
            blast_labels=label_blast(epi.compute_id),
        ))
    return incidents


def get_incident(inc_id: str) -> Incident | None:
    for inc in build_incidents():
        if inc.id.lower() == inc_id.lower():
            return inc
    return None
