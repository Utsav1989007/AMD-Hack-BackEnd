"""Deterministic, seed-based telemetry layered on the *real* topology.

The uploaded CSVs describe structure (the dependency graph) but contain no
time-series logs/metrics. To drive the dashboard, RCA and the vector store we
synthesise coherent telemetry from a fixed seed, so every run — and the
frontend — agree on the same numbers. Swap `Telemetry` for a real
Prometheus/Loki client to go live (same interface).
"""
from __future__ import annotations

import math
from dataclasses import dataclass, field
from datetime import datetime, timedelta, timezone
from functools import lru_cache

from .config import get_settings
from .data_loader import Graph, get_graph

BUCKETS = 72          # 72 * 5min = 6h window
BUCKET_MIN = 5
LEVELS = ["INFO", "WARN", "ERROR"]


class Rng:
    """mulberry32 — identical sequence to the frontend generator."""

    def __init__(self, seed: int):
        self.s = seed & 0xFFFFFFFF

    def next(self) -> float:
        self.s = (self.s + 0x6D2B79F5) & 0xFFFFFFFF
        t = self.s
        t = (t ^ (t >> 15)) * (t | 1) & 0xFFFFFFFF
        t ^= (t + ((t ^ (t >> 7)) * (t | 61) & 0xFFFFFFFF)) & 0xFFFFFFFF
        t &= 0xFFFFFFFF
        return ((t ^ (t >> 14)) & 0xFFFFFFFF) / 4294967296.0

    def rng(self, a: float, b: float) -> float:
        return a + (b - a) * self.next()

    def pick(self, seq):
        return seq[int(self.next() * len(seq)) % len(seq)]


@dataclass
class ComputeSeries:
    compute_id: str
    cpu: list[float]
    latency: list[float]
    error: list[float]
    tput: list[float]


@dataclass
class LogLine:
    ts: str
    level: str
    compute_id: str
    app_id: str | None
    source: str
    message: str


@dataclass
class Epicentre:
    compute_id: str
    kind: str            # oom | latency | errors
    peak_bucket: int


@dataclass
class Telemetry:
    now: datetime
    times: list[str]
    series: dict[str, ComputeSeries]
    logs: list[LogLine]
    volume: list[dict]                  # per-bucket {ts, INFO, WARN, ERROR}
    epicentres: list[Epicentre]
    load: dict[str, float] = field(default_factory=dict)   # compute_id -> mean cpu


LOG_OK = [
    "request completed", "health probe ok", "cache hit ratio nominal",
    "connection pool steady", "gc pause within budget", "checkpoint flushed",
]
LOG_WARN = [
    "elevated p99 latency", "connection pool near capacity", "retry budget consumed",
    "cache miss rate climbing", "thread pool saturation rising", "slow query detected",
]
LOG_ERR = [
    "upstream timeout", "OOMKilled — container restarted", "5xx from dependency",
    "DB connection refused", "deadline exceeded", "circuit breaker opened",
]


def _kind_for(ix: int) -> str:
    return ["oom", "latency", "errors"][ix % 3]


def build_telemetry() -> Telemetry:
    s = get_settings()
    g: Graph = get_graph()
    r = Rng(s.telemetry_seed)

    now = datetime(2026, 6, 14, 4, 0, tzinfo=timezone.utc)
    times = [(now - timedelta(minutes=BUCKET_MIN * (BUCKETS - 1 - i))).isoformat() for i in range(BUCKETS)]

    computes = [n.id for n in g.nodes if n.type == "compute"]

    # baseline load per compute (drives which nodes become epicentres)
    base_load = {c: r.rng(20, 70) for c in computes}
    busiest = sorted(computes, key=lambda c: base_load[c], reverse=True)
    epicentres = [Epicentre(busiest[i], _kind_for(i), int(r.rng(BUCKETS * 0.45, BUCKETS * 0.8)))
                  for i in range(3)]
    epi_by_compute = {e.compute_id: e for e in epicentres}

    series: dict[str, ComputeSeries] = {}
    for c in computes:
        bl = base_load[c]
        cpu, latency, error, tput = [], [], [], []
        epi = epi_by_compute.get(c)
        for i in range(BUCKETS):
            wave = 8 * math.sin(i / 7.0 + bl)
            noise = r.rng(-4, 4)
            cpu_v = bl + wave + noise
            lat_v = 40 + (bl * 0.6) + 12 * math.sin(i / 9.0) + r.rng(-6, 6)
            err_v = max(0, r.rng(0, 2) + (bl - 45) * 0.05)
            tput_v = max(5, 220 - bl + 30 * math.sin(i / 6.0) + r.rng(-15, 15))
            if epi:
                # incident ramp around the peak bucket
                dist = abs(i - epi.peak_bucket)
                surge = max(0.0, 1 - dist / 10.0)
                if epi.kind == "oom":
                    cpu_v += 35 * surge
                    err_v += 14 * surge
                elif epi.kind == "latency":
                    lat_v += 180 * surge
                    err_v += 6 * surge
                else:  # errors
                    err_v += 22 * surge
                    tput_v -= 60 * surge
            cpu.append(round(min(100, max(2, cpu_v)), 1))
            latency.append(round(max(8, lat_v), 1))
            error.append(round(max(0, err_v), 2))
            tput.append(round(max(1, tput_v), 1))
        series[c] = ComputeSeries(c, cpu, latency, error, tput)

    # log stream — volume scales with error level on each compute
    logs: list[LogLine] = []
    for i in range(BUCKETS):
        ts = times[i]
        for c in computes:
            cs = series[c]
            apps = g.apps_on_compute.get(c, [])
            app = r.pick(apps) if apps else None
            err = cs.error[i]
            n_err = int(min(6, round(err / 4)))
            n_warn = 1 if cs.cpu[i] > 78 or cs.latency[i] > 160 else 0
            n_info = 1 if r.next() > 0.55 else 0
            src = f"{c}/{app}" if app else c
            for _ in range(n_err):
                logs.append(LogLine(ts, "ERROR", c, app, src, r.pick(LOG_ERR)))
            for _ in range(n_warn):
                logs.append(LogLine(ts, "WARN", c, app, src, r.pick(LOG_WARN)))
            for _ in range(n_info):
                logs.append(LogLine(ts, "INFO", c, app, src, r.pick(LOG_OK)))

    # per-bucket volume
    volume = []
    by_bucket = {t: {"INFO": 0, "WARN": 0, "ERROR": 0} for t in times}
    for lg in logs:
        by_bucket[lg.ts][lg.level] += 1
    for t in times:
        volume.append({"ts": t, **by_bucket[t]})

    load = {c: round(sum(series[c].cpu) / BUCKETS, 1) for c in computes}

    return Telemetry(now=now, times=times, series=series, logs=logs,
                     volume=volume, epicentres=epicentres, load=load)


@lru_cache
def get_telemetry() -> Telemetry:
    return build_telemetry()
