"""Pure-python analytics over the telemetry: spike detection, forecasting,
service-risk and domain-health scoring. No LLM here — deterministic and fast."""
from __future__ import annotations

from dataclasses import dataclass
from functools import lru_cache

from .data_loader import Graph, get_graph
from .graph_service import blast_radius
from .telemetry import BUCKETS, Telemetry, get_telemetry


@dataclass
class Spike:
    bucket: int
    ts: str
    value: int
    baseline: float
    z: float


def detect_spikes(z_thresh: float = 2.4, window: int = 12) -> list[Spike]:
    tel = get_telemetry()
    err = [v["ERROR"] for v in tel.volume]
    spikes: list[Spike] = []
    for i in range(len(err)):
        lo = max(0, i - window)
        ref = err[lo:i]
        if len(ref) < 4:
            continue
        mean = sum(ref) / len(ref)
        var = sum((x - mean) ** 2 for x in ref) / len(ref)
        std = var ** 0.5 or 1.0
        z = (err[i] - mean) / std
        if z >= z_thresh and err[i] > mean + 3:
            spikes.append(Spike(i, tel.times[i], err[i], round(mean, 1), round(z, 2)))
    return spikes


def noisy_sources(top: int = 8) -> list[dict]:
    tel = get_telemetry()
    counts: dict[str, int] = {}
    errs: dict[str, int] = {}
    for lg in tel.logs:
        counts[lg.source] = counts.get(lg.source, 0) + 1
        if lg.level == "ERROR":
            errs[lg.source] = errs.get(lg.source, 0) + 1
    rows = [{"source": s, "total": counts[s], "errors": errs.get(s, 0)} for s in counts]
    rows.sort(key=lambda x: (x["errors"], x["total"]), reverse=True)
    return rows[:top]


def system_error_series() -> list[float]:
    tel = get_telemetry()
    total = [max(1, v["INFO"] + v["WARN"] + v["ERROR"]) for v in tel.volume]
    return [round(100 * v["ERROR"] / total[i], 2) for i, v in enumerate(tel.volume)]


def forecast(horizon: int = 12) -> dict:
    """Linear trend blended with EWMA, with a simple confidence band."""
    y = system_error_series()
    n = len(y)
    xs = list(range(n))
    mx = sum(xs) / n
    my = sum(y) / n
    denom = sum((x - mx) ** 2 for x in xs) or 1.0
    slope = sum((xs[i] - mx) * (y[i] - my) for i in range(n)) / denom
    intercept = my - slope * mx

    # EWMA level
    alpha = 0.3
    ewma = y[0]
    for v in y[1:]:
        ewma = alpha * v + (1 - alpha) * ewma

    resid = [y[i] - (slope * xs[i] + intercept) for i in range(n)]
    sigma = (sum(r * r for r in resid) / n) ** 0.5

    out = []
    for h in range(1, horizon + 1):
        lin = slope * (n - 1 + h) + intercept
        pred = max(0.0, 0.6 * lin + 0.4 * ewma)
        band = 1.96 * sigma * (1 + h / horizon)
        out.append({
            "step": h,
            "pred": round(pred, 2),
            "low": round(max(0.0, pred - band), 2),
            "high": round(pred + band, 2),
        })
    eta = None
    slo = 3.0
    for p in out:
        if p["pred"] >= slo:
            eta = p["step"]
            break
    return {
        "history": y,
        "forecast": out,
        "slope": round(slope, 4),
        "trend": "rising" if slope > 0.01 else "falling" if slope < -0.01 else "flat",
        "slo": slo,
        "eta_buckets": eta,
        "eta_minutes": eta * 5 if eta else None,
    }


def service_risk(top: int | None = None) -> list[dict]:
    """Predicted failure-risk per business service, propagated up from compute health."""
    g: Graph = get_graph()
    tel: Telemetry = get_telemetry()

    # compute health penalty: recent error + cpu pressure
    comp_pen: dict[str, float] = {}
    win = 30  # last ~2.5h captures the incident peaks
    for cid, cs in tel.series.items():
        recent_err = cs.error[BUCKETS - win:]
        recent_cpu = cs.cpu[BUCKETS - win:]
        peak_err = max(recent_err) if recent_err else 0
        peak_cpu = max(recent_cpu) if recent_cpu else 0
        comp_pen[cid] = min(100.0, peak_err * 3.2 + max(0, peak_cpu - 72) * 1.4)

    rows = []
    for n in g.nodes:
        if n.type != "service":
            continue
        appsvcs = g.appsvc_of_svc.get(n.id, [])
        apps = {g.app_of_appservice.get(a) for a in appsvcs if g.app_of_appservice.get(a)}
        comps = []
        for a in apps:
            comps += g.compute_of_app.get(a, [])
        if not comps:
            continue
        pens = [comp_pen.get(c, 0) for c in comps]
        pen = 0.6 * max(pens) + 0.4 * (sum(pens) / len(pens))
        # criticality weighting from cap->service edges
        crit = 1.0
        for e in g.inc.get(n.id, []):
            if e.criticality == "High":
                crit = 1.25
            elif e.criticality == "Medium":
                crit = max(crit, 1.1)
        risk = round(min(99.0, pen * crit), 1)
        rows.append({
            "id": n.id, "name": n.label, "risk": risk,
            "apps": len(apps), "compute": len(set(comps)),
        })
    rows.sort(key=lambda x: x["risk"], reverse=True)
    return rows[:top] if top else rows


def domain_health() -> list[dict]:
    g: Graph = get_graph()
    risks = {r["id"]: r["risk"] for r in service_risk()}
    out = []
    for n in g.nodes:
        if n.type != "domain":
            continue
        # services under this domain: domain->cap->service
        svc_ids = []
        for e in g.out.get(n.id, []):  # domain -> capability
            cap = e.target
            for e2 in g.out.get(cap, []):  # capability -> service
                if g.by_id.get(e2.target) and g.by_id[e2.target].type == "service":
                    svc_ids.append(e2.target)
        svc_ids = list(set(svc_ids))
        if not svc_ids:
            out.append({"id": n.id, "name": n.label, "services": 0, "risk": 0})
            continue
        avg = sum(risks.get(s, 0) for s in svc_ids) / len(svc_ids)
        out.append({"id": n.id, "name": n.label, "services": len(svc_ids), "risk": round(avg, 1)})
    out.sort(key=lambda x: x["risk"], reverse=True)
    return out


@lru_cache
def kpis() -> dict:
    tel = get_telemetry()
    spikes = detect_spikes()
    errs = sum(v["ERROR"] for v in tel.volume)
    total = sum(v["INFO"] + v["WARN"] + v["ERROR"] for v in tel.volume)
    risk = service_risk()
    at_risk = len([r for r in risk if r["risk"] >= 50])
    return {
        "log_volume": total,
        "error_rate": round(100 * errs / max(1, total), 2),
        "spikes": len(spikes),
        "epicentres": len(tel.epicentres),
        "services_at_risk": at_risk,
        "total_services": len(risk),
        "forecast_trend": forecast()["trend"],
    }
