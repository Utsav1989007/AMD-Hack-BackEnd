"""Loads the 13 infrastructure CSVs into an in-memory topology graph + lineage maps.

Node id prefixes:  BD* domain, BC* capability, BS* business-service,
AS* app-service/API, APP* application, C* compute, DB* database, N* network.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from functools import lru_cache
from pathlib import Path

import pandas as pd

from .config import get_settings

# node type -> presentation metadata (kept in sync with the frontend LAYER map)
LAYER = {
    "domain":     {"idx": 0, "label": "Business Domain",   "glyph": "◆"},
    "capability": {"idx": 1, "label": "Capability",        "glyph": "▣"},
    "service":    {"idx": 2, "label": "Business Service",  "glyph": "●"},
    "appservice": {"idx": 3, "label": "App Service / API", "glyph": "▸"},
    "app":        {"idx": 4, "label": "Application",       "glyph": "▢"},
    "compute":    {"idx": 5, "label": "Compute",           "glyph": "▰"},
    "database":   {"idx": 5, "label": "Database",          "glyph": "◰"},
    "network":    {"idx": 5, "label": "Network",           "glyph": "◇"},
}


@dataclass
class Node:
    id: str
    label: str
    type: str
    meta: dict = field(default_factory=dict)


@dataclass
class Edge:
    source: str
    target: str
    rel: str
    criticality: str | None = None
    weight: float | None = None


@dataclass
class Graph:
    nodes: list[Node]
    edges: list[Edge]
    by_id: dict[str, Node]
    adj: dict[str, set[str]]          # undirected neighbours
    out: dict[str, list[Edge]]        # outgoing edges
    inc: dict[str, list[Edge]]        # incoming edges

    # lineage convenience maps
    svc_of_appservice: dict[str, list[str]] = field(default_factory=dict)
    appsvc_of_svc: dict[str, list[str]] = field(default_factory=dict)
    app_of_appservice: dict[str, str] = field(default_factory=dict)
    compute_of_app: dict[str, list[str]] = field(default_factory=dict)
    db_of_app: dict[str, list[str]] = field(default_factory=dict)
    apps_on_compute: dict[str, list[str]] = field(default_factory=dict)
    metrics_of_compute: dict[str, list[tuple[str, float]]] = field(default_factory=dict)

    def neighbors(self, node_id: str) -> list[str]:
        return sorted(self.adj.get(node_id, set()))


def _read(data_dir: Path, name: str) -> pd.DataFrame:
    df = pd.read_csv(data_dir / f"{name}.csv", skipinitialspace=True)
    df.columns = [c.strip() for c in df.columns]
    for col in df.columns:
        if df[col].dtype == object:
            df[col] = df[col].map(lambda v: v.strip() if isinstance(v, str) else v)
    return df


def build_graph() -> Graph:
    s = get_settings()
    d = s.data_path

    domains = _read(d, "business_domain")
    caps = _read(d, "business_capability")
    svcs = _read(d, "business_service")
    apps = _read(d, "application")
    appsvcs = _read(d, "application_service")
    compute = _read(d, "compute")
    database = _read(d, "database")
    network = _read(d, "network")

    rel_cap_svc = _read(d, "rel_cap_service")
    rel_svc_app = _read(d, "rel_service_app")
    rel_app_comp = _read(d, "rel_app_compute")
    rel_app_db = _read(d, "rel_app_db")
    rel_obs = _read(d, "rel_observability")

    nodes: list[Node] = []
    by_id: dict[str, Node] = {}

    def add(nid, label, ntype, **meta):
        n = Node(id=nid, label=label, type=ntype, meta=meta)
        nodes.append(n)
        by_id[nid] = n

    for _, r in domains.iterrows():
        add(r["domain_id"], r["domain_name"], "domain")
    for _, r in caps.iterrows():
        add(r["capability_id"], r["capability_name"], "capability", domain_id=r["domain_id"])
    for _, r in svcs.iterrows():
        add(r["service_id"], r["service_name"], "service", capability_id=r["capability_id"])
    for _, r in appsvcs.iterrows():
        add(r["app_service_id"], r["service_name"], "appservice", app_id=r["app_id"])
    for _, r in apps.iterrows():
        add(r["app_id"], r["app_name"], "app", owner_domain=r["owner_domain"])
    for _, r in compute.iterrows():
        add(r["compute_id"], f'{r["type"]} · {r["region"]}', "compute",
            ctype=r["type"], region=r["region"])
    for _, r in database.iterrows():
        add(r["db_id"], r["db_name"], "database", dbtype=r["type"])
    for _, r in network.iterrows():
        add(r["network_id"], r["type"], "network")

    edges: list[Edge] = []

    def link(src, tgt, rel, criticality=None, weight=None):
        if src in by_id and tgt in by_id:
            edges.append(Edge(src, tgt, rel, criticality, weight))

    # hierarchy edges
    for _, r in caps.iterrows():
        link(r["domain_id"], r["capability_id"], "CONTAINS")
    for _, r in svcs.iterrows():
        link(r["capability_id"], r["service_id"], "GROUPS")
    for _, r in appsvcs.iterrows():
        link(r["app_id"], r["app_service_id"], "EXPOSES")
    # relationship edges
    for _, r in rel_cap_svc.iterrows():
        link(r["source_id"], r["target_id"], r["relation_type"], criticality=r.get("criticality"))
    for _, r in rel_svc_app.iterrows():
        link(r["source_id"], r["target_id"], r["relation_type"], criticality=r.get("criticality"))
    for _, r in rel_app_comp.iterrows():
        link(r["source_id"], r["target_id"], r["relation_type"])
    for _, r in rel_app_db.iterrows():
        link(r["source_id"], r["target_id"], r["relation_type"])

    # adjacency / indices
    adj: dict[str, set[str]] = {n.id: set() for n in nodes}
    out: dict[str, list[Edge]] = {n.id: [] for n in nodes}
    inc: dict[str, list[Edge]] = {n.id: [] for n in nodes}
    for e in edges:
        adj[e.source].add(e.target)
        adj[e.target].add(e.source)
        out[e.source].append(e)
        inc[e.target].append(e)

    g = Graph(nodes=nodes, edges=edges, by_id=by_id, adj=adj, out=out, inc=inc)

    # lineage maps
    for _, r in appsvcs.iterrows():
        g.app_of_appservice[r["app_service_id"]] = r["app_id"]
    for _, r in rel_svc_app.iterrows():
        g.svc_of_appservice.setdefault(r["target_id"], []).append(r["source_id"])
        g.appsvc_of_svc.setdefault(r["source_id"], []).append(r["target_id"])
    for _, r in rel_app_comp.iterrows():
        g.compute_of_app.setdefault(r["source_id"], []).append(r["target_id"])
        g.apps_on_compute.setdefault(r["target_id"], []).append(r["source_id"])
    for _, r in rel_app_db.iterrows():
        g.db_of_app.setdefault(r["source_id"], []).append(r["target_id"])
    for _, r in rel_obs.iterrows():
        try:
            w = float(r.get("weight", 0) or 0)
        except (TypeError, ValueError):
            w = 0.0
        g.metrics_of_compute.setdefault(r["target_id"], []).append((r["source_id"], w))

    return g


@lru_cache
def get_graph() -> Graph:
    return build_graph()
